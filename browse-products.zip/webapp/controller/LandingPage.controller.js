sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/Label",
	"sap/ui/core/BusyIndicator",
	"sap/m/MessageToast",
	"sap/m/MessageBox"
], function (BaseController, JSONModel, formatter, Filter, FilterOperator, Label, BusyIndicator, MessageToast, MessageBox) {
	"use strict";

	return BaseController.extend("dvt.browse-products.controller.LandingPage", {

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {

			this.oViewModel = new JSONModel({
				productFrom: "",
				productTo: "",
				mainCategory: "",
				ratingFrom: "",
				ratingTo: "",
				aProducts: [],
				sFlag: ""
			});

			this.setModel(this.oViewModel, "oViewModel");
			this.getRouter().attachRouteMatched(this._attachRouteMatched, this);

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		onSubmit: function (oEvent) {
			//var oViewModel = this.getView().getModel("oViewModel");
			var oInputMainCategory = this.byId("mainCategory");
			var oInputRating = this.byId("rating");
			var oInputRatingTo = this.byId("ratingTo");
			//var oComboProductFrom = this.byId("productFrom").getSelectedKey();
			//var oComboProductTo = this.byId("productTo").getSelectedKey();

			var sMainCategory = oInputMainCategory.getValue();
			if (sMainCategory === "") {
				sMainCategory = "ALL";
			}

			//var sRating = oInputRating.getValue();
			//ar sRatingTo = oInputRatingTo.getValue();

			//MessageToast.show("Prod from is : " + oComboProductFrom +  "Prod To is : " + oComboProductTo);

			this.oViewModel.setProperty("/mainCategory", sMainCategory);
			this.oViewModel.setProperty("/productFrom", this.byId("productFrom").getSelectedKey());
			this.oViewModel.setProperty("/productTo", this.byId("productTo").getSelectedKey());
			this.oViewModel.setProperty("/ratingFrom", oInputRating.getValue());
			this.oViewModel.setProperty("/ratingTo", oInputRatingTo.getValue());
			
			var sMessage = "Navigate to the Product Page?";
			MessageBox.confirm(
				sMessage,
				this._GotoWorklist.bind(this), "Confirmation"

			);

			// this.getRouter().navTo("worklist", {
			// 	MainCategory: sMainCategory,
			// 	Rating: sRating,
			// 	RatingTo: sRatingTo,
			// 	ProductFrom: oComboProductFrom,
			// 	ProductTo: oComboProductTo
			// });

		},
		_GotoWorklist: function (sFlag) {
			if (sFlag === "OK") {
				this.getRouter().navTo("worklist", {
					MainCategory: this.oViewModel.getProperty("/mainCategory"),
					Rating: this.oViewModel.getProperty("/ratingFrom"),
					RatingTo: this.oViewModel.getProperty("/ratingTo"),
					ProductFrom: this.oViewModel.getProperty("/productFrom"),
					ProductTo: this.oViewModel.getProperty("/productTo")
				});
			}
		},
		/* =========================================================== */
		/* Private functions                                           */
		/* =========================================================== */
		_attachRouteMatched: function (oEvent) {
			var params = oEvent.getParameters();
			if (params.name === "landingPage") {
				//MessageToast.show(params.name);
			}
		}
	});
});